<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'bd_examen_wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'R(.c_#x;Od4O=^`DV<<bR05o~GlsD81JgN#QQ~w: %1{D$idx,9IE-QW99ELvP%U' );
define( 'SECURE_AUTH_KEY',  '$/~t}5~~eet/)/de/>` Cap.G*M0NH>n,}[7trHI:/s{,9FY9D/R@[}^jP$BwP/O' );
define( 'LOGGED_IN_KEY',    '8D+DZl#~SmJWJg*,1KQDZ];eSU_$+pCZ6{JhsCDI>dt@S@VFy{jv#0!E0`DdV.**' );
define( 'NONCE_KEY',        'lNFaMB]@Q!N;fd |?`z[>I ^7g_]% [BS)O=u{D`()Y^OR0Zcc8Pob,d}O67uD8B' );
define( 'AUTH_SALT',        '1JELa:eQ|2T=)v3:q.2Klo<KB7%]X2FMf/.=IMwhWw87)KHx|iUN )&9|8iz/_Hg' );
define( 'SECURE_AUTH_SALT', '%9YTMkdChq|x=t>B$oH7j`Qd[zmP5Ab+])o%E:>}>{ro<}BAE%&^t+5_UGl2Epor' );
define( 'LOGGED_IN_SALT',   '7AK;g{6}4JEQB8T1w1?|jiVd?`:>0bs8Er.]QQs#bV8$q4wI2)H<8m;K[pL #}aJ' );
define( 'NONCE_SALT',       '6f.RpPKBlYog=U=*d8Y%s_ol/JnU?UV@FWO|,7)k:ZjwpTTH$C`P?MqHo-1/?l^^' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
